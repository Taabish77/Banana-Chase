var bananaImage,obstacleImage,obstacleGroup,stone;
var groundImage,ground,score,banana,monkeyImage,monkey;


function preload(){
bananaImage=loadImage("banana.png");
monkeyImage=loadAnimation("M1.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png","M10.png");
  obstacleImage=loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);
  monkey = createSprite(180,180,20,20);  
  banana = createSprite(300,200,10,5);
  ground = createSprite(200,180,400,20);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  ground.velocityX = -(6+3*score/100);
banana.addImage(bananaImage);
monkey.addAnimation(monkeyImage);
  monkey.scale=0.3;
  
   invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
  
}

function draw(){
background("blue");
  text("score"+score,350,50);
  drawSprites();
  if(keyDown("space")&&monkey.y>=159) {
    monkey.velocityY = -14;
  }
  rock(); 
  
  monkey.velocityY = monkey.velocityY + 0.8                         
  
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  monkey.collide(invisibleGround);
  
  if(monkey.isTouching(stone)){
  invisibleGround.velocity=0;   
 banana.velocity=0;   
    monkey.velocity=0;   
    
    } 
}
function rock() {
 if (frameCount % 80 === 0) {
   stone=createSprite(200,190,20,20);
   stone.addImage("obstacleImage") ;
   stone.scale = 0.1;
    stone.velocityX = -3;
    stone.scale=0.8;    
 stone.lifetime = 300;

 }
}
